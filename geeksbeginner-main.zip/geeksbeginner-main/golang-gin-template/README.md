# Golang Gin Template

An example of golang web development using HTML template using Gin framework.

## More documentation
A fully description of this project is available at http://www.geeksbeginner.com/golang-web-development-with-template-and-gin-framework/

## Build
```
cd src/web
go build
```